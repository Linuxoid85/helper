VERSION="0.06.2020"
DIALOG=${DIALOG=dialog}
DATE=`date`
$DIALOG --backtitle "Helper $VERSION -- просмотр справки. Дата: $DATE" --title " Helper - о программе " --yesno "  Helper - помощник новичка. В нём описаны несколько утилит - 
APT, DPKG, GDEBI и EOPKG, но в будущем планируется добавить и другие. 
  Это более понятный и краткий аналог легендарных манов с некоторыми 
ненужными фичами.
 Версия Helper: $VERSION.

-------------------- Ссылки на другие проекты -------------------
1. www.vk.com/club_image_linux		- внешний вид Linux
2. www.vk.com/linuxparadise		- новости и игры
3. www.vk.com/nixscript			- терминал Linux
4. www.vk.com/linuxsovet		- наша группа

-----------------------------------------------------------------
(C) @linuxoid85 специально для ''Советы по Linux/GNU Linux'', 2020" 20 70 
