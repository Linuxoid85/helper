#Первая помощь по утилите apt, dpkg, eopkg и urpmX (в планах добавить справку и по другим пакетным менеджерам)

#Больше информации вы можете найти по адресу www.vk.com/linuxsovet
#Если у Вас есть вопрос или замечание, то напишите на почту michail666krasnov@mail.ru , на мою страницу ВК www.vk.com/linuxoid85 или в сообщения www.vk.com/linuxsovet

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

#(C) @linuxoid85 специально для "Советы по Linux/GNU Linux", 2020

#/bin/bash

version() {
    echo
    echo "Версия \e[1mHelper\e[0m:
0.06.2020" #Версию можно ещё в переменную запилить, но я не хочу. Использую эту функцию ещё и в головном скрипте...
}

menu() {
clear 
echo "\e[1;34m======================== Помощь по пакетным менеджерам ========================\e[0m"

echo "Версия \e[1mMORE\e[0m:" && more -V

version
echo
}

menu
echo "\e[1mВремя:\e[0m" && date

echo
echo "\e[1mТекущий календарь:\e[0m" && cal

echo
echo "\e[1mПогода:\e[0m" && inxi -w
